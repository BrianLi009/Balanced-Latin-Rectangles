"""Independent, exact audit. Run from any directory: python audit/check_results.py.
Does not import the repository checker or modify the original results.
"""
from pathlib import Path
from collections import Counter, defaultdict
import csv, json, re, statistics, hashlib
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
def rows(path):
 return list(csv.DictReader(x for x in (ROOT/path).read_text().splitlines() if not x.startswith('#')))
def check_rectangle(R,k=None,n=None):
 assert R and R[0], 'empty rectangle'
 k0,n0=len(R),len(R[0])
 assert k is None or k==k0
 assert n is None or n==n0
 k,n=k0,n0
 assert 1<=k<=n
 for row in R: assert len(row)==n and set(row)==set(range(1,n+1))
 for col in zip(*R): assert len(set(col))==k
 # Accumulate distances by visiting pairs of physical columns, rather than inverting rows.
 distances=Counter()
 for row in R:
  for a in range(n):
   for b in range(a+1,n): distances[tuple(sorted((row[a],row[b])))]+=b-a
 assert len(distances)==n*(n-1)//2
 assert sum(distances.values())==k*n*(n*n-1)//6
 return sum(abs(3*d-k*(n+1)) for d in distances.values())
def read_R(path):
 return [list(map(int,l.split())) for l in path.read_text().splitlines() if l and not l.startswith(('#','COST3'))]
def display(c):
 q,r=divmod(c,3);return f'{q}.{[0,3,6][r]}'
def main():
 expected={(k,n) for n in range(8,14) for k in range(2,n)}
 baseline={(int(r['k']),int(r['n'])):int(r['imbalance3']) for r in rows('data/previous_best.csv')}
 # Independently transcribed from CP 2025 Table 1, DOI 10.4230/LIPIcs.CP.2025.36.
 table={8:'40.0 36.0 32.0 30.0 24.0 28.0',9:'65.3 56.0 56.0 52.6 48.0 51.3 53.3',10:'92.0 80.0 78.6 66.6 70.0 72.0 82.6 70.0',11:'124.0 114.0 112.0 116.0 108.0 118.0 114.0 120.0 110.0',12:'168.0 154.0 154.6 145.3 120.0 164.0 148.0 154.0 174.6 147.3',13:'218.6 198.0 211.3 210.6 204.0 203.3 220.6 214.0 240.6 224.0 274.0'}
 def parse(s):
  a,b=s.split('.');return 3*int(a)+{'0':0,'3':1,'6':2}[b]
 source={(k,n):parse(v) for n,s in table.items() for k,v in enumerate(s.split(),2)}
 assert baseline==source and set(baseline)==expected
 raw={}; manifests=[]
 for path in sorted((ROOT/'results/raw').glob('*.txt')):
  k,n,seed=map(int,re.fullmatch(r'r_(\d+)_(\d+)_s(\d+)\.txt',path.name).groups())
  c=check_rectangle(read_R(path),k,n)
  assert c==int(path.read_text().splitlines()[0].split()[1])
  raw[k,n,seed]=c
  manifests.append({'file':str(path.relative_to(ROOT)),'k':k,'n':n,'seed':seed,'cost3':c,'verified':True})
 want={(k,n,s) for k,n in expected for s in (1,2)}|{(k,n,3) for k,n in expected if k>=4 and n>=9}
 assert set(raw)==want
 rr=rows('results/results.csv');assert len(rr)==len(expected)
 status=Counter();gains=[];percell=[]
 assert {(int(r['k']),int(r['n'])) for r in rr}==expected
 assert len(list((ROOT/'results/rectangles').glob('*.txt')))==len(expected)
 for r in rr:
  k,n=int(r['k']),int(r['n']);old,new=int(r['previous_imbalance3']),int(r['new_imbalance3'])
  assert old==baseline[k,n]
  assert new==min(v for (kk,nn,s),v in raw.items() if (kk,nn)==(k,n))
  assert new==check_rectangle(read_R(ROOT/f'results/rectangles/k{k}_n{n}.txt'),k,n)
  state='improved' if new<old else 'matched' if new==old else 'worse'
  assert r['status']==state and r['new']==display(new) and r['previous']==display(old)
  status[state]+=1
  gain=100*(old-new)/old
  if new<old:gains.append(gain)
  percell.append(dict(k=k,n=n,previous3=old,new3=new,gain_pct=gain,status=state,verified=True))
 budget=rows('results/budget.csv');assert len(budget)==len(raw)
 seed_of={60:1,300:2,600:3}
 for r in budget:assert int(r['imbalance3'])==raw[int(r['k']),int(r['n']),seed_of[int(r['seconds'])]]
 tr=rows('results/timing.csv'); beat=[r for r in tr if r['kind']=='beat_cp2025'];match=[r for r in tr if r['kind']=='match_cp2023']
 improved={(r['k'],r['n']) for r in percell if r['status']=='improved'}
 assert {(int(r['k']),int(r['n']),int(r['seed'])) for r in beat}=={(k,n,s) for k,n in improved for s in range(101,106)}
 assert len(beat)==165 and len(match)==20 and all(r['reached']=='1' for r in tr)
 sat={(3,10):(252,1920),(4,11):(354,6120),(6,10):(288,2400),(6,11):(372,19800)}
 assert {(int(r['k']),int(r['n']),int(r['seed'])) for r in match}=={(k,n,s) for k,n in sat for s in range(101,106)}
 for r in tr:
  k,n=int(r['k']),int(r['n']);target=int(r['target3'])
  if r['kind']=='beat_cp2025':assert target==baseline[k,n]-1
  else:assert (target,float(r['reference_seconds']))==sat[k,n]
  assert int(r['best3'])<=target and 0<=float(r['seconds'])<=300
 times=[float(r['seconds']) for r in beat]
 medians={(k,n):statistics.median(float(r['seconds']) for r in beat if (int(r['k']),int(r['n']))==(k,n)) for k,n in improved}
 full={(k,n) for k,n,s in raw if s==3}
 bmeans={str(t):statistics.mean(100*(baseline[k,n]-raw[k,n,s])/baseline[k,n] for k,n in full) for s,t in [(1,60),(2,300),(3,600)]}
 published=[]
 for p in sorted((ROOT/'data/published').glob('*.txt')):
  c=check_rectangle(read_R(p));claim=re.search('reported imbalance ([0-9.]+)',p.read_text()).group(1)
  assert display(c)==claim;published.append({'file':p.name,'cost3':c})
 summary={'source_commit':'ee17187b5e7b023c67e9fb998f0113f4348cea12','baseline_entries_checked_against_CP2025':51,'raw_runs_verified':len(raw),'final_witnesses_verified':len(rr),'published_fixtures_verified':len(published),'status':dict(status),'mean_gain_improved_pct':statistics.mean(gains),'max_gain_pct':max(gains),'mean_gain_all51_pct':sum(gains)/51,'one_minute_improvements':sum(raw[k,n,1]<baseline[k,n] for k,n in expected),'full_budget_cells':len(full),'budget_mean_gain_pct':bmeans,'saved_timing_rows':len(tr),'saved_beat_median_seconds':statistics.median(times),'saved_beat_max_seconds':max(times),'max_instance_median_seconds':max(medians.values()),'instances_median_under1':sum(v<1 for v in medians.values()),'instances_median_under60':sum(v<60 for v in medians.values()),'saved_SAT_match_max_seconds':max(float(r['seconds']) for r in match),'saved_SAT_min_ratio':min(ref/statistics.median(float(r['seconds']) for r in match if (int(r['k']),int(r['n']))==(k,n)) for (k,n),(target,ref) in sat.items()),'caution':'Saved timing arithmetic checked; historic timings and machine provenance cannot be authenticated from this CSV.'}
 (OUT/'result_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 for name,records in [('raw_witness_checks.csv',manifests),('instance_checks.csv',percell),('published_fixture_checks.csv',published)]:
  with (OUT/name).open('w') as f:w=csv.DictWriter(f,fieldnames=records[0].keys());w.writeheader();w.writerows(records)
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
