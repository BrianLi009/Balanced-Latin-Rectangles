"""Fresh, isolated rerun; saves every witness and stderr. Does not overwrite published data."""
from check_results import ROOT, OUT, check_rectangle, rows
import subprocess, concurrent.futures, json, csv, time, platform, os
def main():
 out=OUT/'fresh_timing';out.mkdir(exist_ok=True)
 binary=out/'sa'
 subprocess.run(['cc','-O3','-Wall','-Wextra','-Wpedantic','-o',str(binary),str(ROOT/'code/sa.c'),'-lm'],check=True)
 env={'platform':platform.platform(),'compiler':subprocess.check_output(['cc','--version'],text=True),'cpu':subprocess.check_output(['lscpu'],text=True),'command':'cc -O3 -Wall -Wextra -Wpedantic -o sa code/sa.c -lm','jobs':8,'cap_cpu_seconds':300,'source_commit':'ee17187b5e7b023c67e9fb998f0113f4348cea12'}
 (out/'environment.json').write_text(json.dumps(env,indent=2))
 def run(row):
  tag=f"{row['kind']}_{row['k']}_{row['n']}_{row['seed']}"
  cmd=[str(binary),row['k'],row['n'],'300',row['seed'],row['target3']]
  start=time.monotonic();p=subprocess.run(cmd,text=True,capture_output=True,timeout=900)
  (out/(tag+'.txt')).write_text(p.stdout);(out/(tag+'.stderr')).write_text(p.stderr)
  assert p.returncode==0,(cmd,p.stderr)
  lines=p.stdout.splitlines();c=int(lines[0].split()[1]);R=[list(map(int,l.split())) for l in lines[1:]]
  assert check_rectangle(R,int(row['k']),int(row['n']))==c
  sec=float(p.stderr.split('TIME_TO_BEST ')[1].split()[0])
  return dict(kind=row['kind'],k=row['k'],n=row['n'],seed=row['seed'],target3=row['target3'],best3=c,reached=c<=int(row['target3']),cpu_seconds=sec,wall_seconds=time.monotonic()-start,saved_cpu_seconds=row['seconds'])
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  results=[]
  for r in pool.map(run,rows('results/timing.csv')):
   results.append(r)
   with (out/'results.json').open('w') as f:json.dump(results,f,indent=2)
 print(json.dumps({'runs':len(results),'reached':sum(r['reached'] for r in results)}))
if __name__=='__main__':main()
